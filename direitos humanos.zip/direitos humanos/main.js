var passo;
for (passo = 0; passo < 5; passo++) {
  console.log(passo +' Ande um passo para o leste');
}
 function opa(sla) {
   if ( sla > passo ) {
     console.log("coral")
   } else {
     console.log("alguma coisa")
   }
 } 
 opa(6)
 console.log(passo + " era uma vez um sla q vivia fazendo pipi um dia o elfo se aborreceu e na porta do doente bateu e nesse dia eles se apaixonaram")